// the configured options and settings for Tutorial
#define Tutorial_VERSION_MAJOR 1
#define Tutorial_VERSION_MINOR 0
#define USE_MYMATH

// does the platform provide exp and log functions?
/* #undef HAVE_LOG */
/* #undef HAVE_EXP */
